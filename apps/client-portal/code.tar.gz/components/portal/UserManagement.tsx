'use client';

import { useEffect, useState } from 'react';
import { useMondayContext } from '@/lib/monday-context';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Loader } from '@/components/ui/Loader';
import { Select } from '@/components/ui/Select';
import { Plus, RefreshCw, Mail, Building2, Key } from 'lucide-react';

interface User {
  id: string;
  email: string;
  company: string;
  companyId: string;
  status: string;
  createdDate: string;
  lastLogin?: string;
}

export default function UserManagement() {
  const { executeMondayQuery } = useMondayContext();
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<User[]>([]);
  const [companies, setCompanies] = useState<Array<{ id: string; name: string }>>([]);
  const [showNewUser, setShowNewUser] = useState(false);
  const [userEmail, setUserEmail] = useState('');
  const [userPassword, setUserPassword] = useState('');
  const [selectedCompanyId, setSelectedCompanyId] = useState('');
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    loadUsers();
    loadCompanies();
  }, []);

  const loadUsers = async () => {
    try {
      setLoading(true);

      const query = `
        query GetUsers($boardId: [ID!]!) {
          boards(ids: $boardId) {
            items_page(limit: 500) {
              items {
                id
                name
                column_values {
                  id
                  text
                  value
                }
                created_at
              }
            }
          }
        }
      `;

      const response = await executeMondayQuery(query, {
        boardId: ['18379351659'] // User board
      });

      if (response.data?.boards?.[0]?.items_page?.items) {
        const items = response.data.boards[0].items_page.items;
        
        const usersList: User[] = items.map((item: any) => {
          const cols = item.column_values.reduce((acc: any, col: any) => {
            acc[col.id] = col.text || col.value;
            return acc;
          }, {});

          return {
            id: item.id,
            email: cols.text || item.name,
            company: cols.dropdown || '',
            companyId: '',
            status: cols.status || 'Active',
            createdDate: item.created_at
          };
        });

        setUsers(usersList);
      }
    } catch (err) {
      console.error('Failed to load users:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadCompanies = async () => {
    try {
      const query = `
        query GetCompanies($boardId: [ID!]!) {
          boards(ids: $boardId) {
            items_page(limit: 100) {
              items {
                id
                name
              }
            }
          }
        }
      `;

      const response = await executeMondayQuery(query, {
        boardId: ['18379404757']
      });

      if (response.data?.boards?.[0]?.items_page?.items) {
        setCompanies(
          response.data.boards[0].items_page.items.map((item: any) => ({
            id: item.id,
            name: item.name
          }))
        );
      }
    } catch (err) {
      console.error('Failed to load companies:', err);
    }
  };

  const createUser = async () => {
    if (!userEmail.trim() || !userPassword.trim() || !selectedCompanyId) {
      alert('Please fill in all fields');
      return;
    }

    try {
      setCreating(true);

      const mutation = `
        mutation CreateUser($boardId: ID!, $itemName: String!, $columnValues: JSON!) {
          create_item(
            board_id: $boardId,
            item_name: $itemName,
            column_values: $columnValues
          ) {
            id
          }
        }
      `;

      const selectedCompany = companies.find(c => c.id === selectedCompanyId);

      await executeMondayQuery(mutation, {
        boardId: '18379351659',
        itemName: userEmail,
        columnValues: JSON.stringify({
          text: { text: userEmail },
          text4: { text: userPassword },
          dropdown: { label: selectedCompany?.name || '' },
          status: { label: 'Active' }
        })
      });

      alert(`User "${userEmail}" created successfully!`);
      
      setShowNewUser(false);
      setUserEmail('');
      setUserPassword('');
      setSelectedCompanyId('');
      loadUsers();

    } catch (err) {
      console.error('Failed to create user:', err);
      alert('Failed to create user');
    } finally {
      setCreating(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900">User Management</h2>
          <p className="text-sm text-gray-600 mt-1">
            Manage client portal users and access
          </p>
        </div>
        <div className="flex gap-3">
          <Button onClick={loadUsers} variant="secondary">
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
          <Button onClick={() => setShowNewUser(true)}>
            <Plus className="w-4 h-4 mr-2" />
            New User
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-4">
          <div className="text-sm font-medium text-gray-600">Total Users</div>
          <div className="text-2xl font-bold text-gray-900 mt-1">{users.length}</div>
        </Card>
        <Card className="p-4">
          <div className="text-sm font-medium text-gray-600">Active Users</div>
          <div className="text-2xl font-bold text-green-600 mt-1">
            {users.filter(u => u.status === 'Active').length}
          </div>
        </Card>
        <Card className="p-4">
          <div className="text-sm font-medium text-gray-600">Companies</div>
          <div className="text-2xl font-bold text-blue-600 mt-1">{companies.length}</div>
        </Card>
      </div>

      {/* Users Table */}
      <Card>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Email
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Company
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                  Created
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {users.map((user) => (
                <tr key={user.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-900">{user.email}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-700">{user.company || 'Not assigned'}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      user.status === 'Active' 
                        ? 'bg-green-100 text-green-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {user.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    {new Date(user.createdDate).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* New User Modal */}
      {showNewUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <Card className="max-w-md w-full p-6">
            <h3 className="text-lg font-bold mb-4">Create New User</h3>
            <div className="space-y-4">
              <Input
                label="Email"
                type="email"
                value={userEmail}
                onChange={(e) => setUserEmail(e.target.value)}
                placeholder="user@company.com"
                disabled={creating}
              />
              <Input
                label="Password"
                type="password"
                value={userPassword}
                onChange={(e) => setUserPassword(e.target.value)}
                placeholder="••••••••"
                disabled={creating}
              />
              <Select
                label="Company"
                value={selectedCompanyId}
                onChange={(e) => setSelectedCompanyId(e.target.value)}
                disabled={creating}
              >
                <option value="">Select a company...</option>
                {companies.map((company) => (
                  <option key={company.id} value={company.id}>
                    {company.name}
                  </option>
                ))}
              </Select>
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <Button
                variant="secondary"
                onClick={() => {
                  setShowNewUser(false);
                  setUserEmail('');
                  setUserPassword('');
                  setSelectedCompanyId('');
                }}
                disabled={creating}
              >
                Cancel
              </Button>
              <Button onClick={createUser} disabled={creating}>
                {creating ? 'Creating...' : 'Create User'}
              </Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
